<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill;

/**
 * Describes the values a lookup can return.
 *
 * The token names match the keys used by the Razorpay IFSC service so a raw
 * response can be normalised without a translation table.
 */
final class IfscTokens {

  /**
   * Length of a valid IFSC code.
   */
  public const CODE_LENGTH = 11;

  /**
   * Regular expression every IFSC code must satisfy.
   */
  public const PATTERN = '/^[A-Z]{4}0[A-Z0-9]{6}$/';

  /**
   * Tokens offered as autofill targets, keyed by response key.
   *
   * @return array<string, \Drupal\Core\StringTranslation\TranslatableMarkup>
   *   Token name keyed labels.
   */
  public static function definitions(): array {
    return [
      'BANK' => t('Bank name'),
      'BRANCH' => t('Branch name'),
      'ADDRESS' => t('Branch address'),
      'CITY' => t('City'),
      'DISTRICT' => t('District'),
      'STATE' => t('State'),
      'CENTRE' => t('Centre'),
      'CONTACT' => t('Contact number'),
      'MICR' => t('MICR code'),
      'BANKCODE' => t('Bank code'),
      'SWIFT' => t('SWIFT code'),
      'IFSC' => t('IFSC code (normalised)'),
      'NEFT' => t('NEFT supported'),
      'RTGS' => t('RTGS supported'),
      'IMPS' => t('IMPS supported'),
      'UPI' => t('UPI supported'),
    ];
  }

  /**
   * Token names only.
   *
   * @return string[]
   *   The supported token names.
   */
  public static function names(): array {
    return array_keys(self::definitions());
  }

  /**
   * Checks whether a token is supported.
   *
   * @param string $token
   *   The token name.
   *
   * @return bool
   *   TRUE when the token is known.
   */
  public static function isValid(string $token): bool {
    return array_key_exists($token, self::definitions());
  }

}
