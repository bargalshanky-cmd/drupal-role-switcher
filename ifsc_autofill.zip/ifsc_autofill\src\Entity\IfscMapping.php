<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\ifsc_autofill\IfscMappingInterface;

/**
 * Binds an IFSC source field to the fields that receive the lookup result.
 *
 * @ConfigEntityType(
 *   id = "ifsc_mapping",
 *   label = @Translation("IFSC mapping"),
 *   label_collection = @Translation("IFSC mappings"),
 *   label_singular = @Translation("IFSC mapping"),
 *   label_plural = @Translation("IFSC mappings"),
 *   label_count = @PluralTranslation(
 *     singular = "@count IFSC mapping",
 *     plural = "@count IFSC mappings"
 *   ),
 *   handlers = {
 *     "list_builder" = "Drupal\ifsc_autofill\IfscMappingListBuilder",
 *     "form" = {
 *       "add" = "Drupal\ifsc_autofill\Form\IfscMappingForm",
 *       "edit" = "Drupal\ifsc_autofill\Form\IfscMappingForm",
 *       "delete" = "Drupal\ifsc_autofill\Form\IfscMappingDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider"
 *     }
 *   },
 *   config_prefix = "mapping",
 *   admin_permission = "administer ifsc autofill",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "status" = "status"
 *   },
 *   links = {
 *     "collection" = "/admin/config/services/ifsc-autofill/mappings",
 *     "add-form" = "/admin/config/services/ifsc-autofill/mappings/add",
 *     "edit-form" = "/admin/config/services/ifsc-autofill/mappings/{ifsc_mapping}",
 *     "delete-form" = "/admin/config/services/ifsc-autofill/mappings/{ifsc_mapping}/delete"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "status",
 *     "target_entity_type",
 *     "target_bundle",
 *     "source_field",
 *     "targets",
 *     "overwrite",
 *     "lock_targets"
 *   }
 * )
 */
class IfscMapping extends ConfigEntityBase implements IfscMappingInterface {

  /**
   * The machine name.
   *
   * @var string
   */
  protected $id;

  /**
   * The human readable label.
   *
   * @var string
   */
  protected $label;

  /**
   * The entity type this mapping applies to.
   *
   * @var string
   */
  protected $target_entity_type = '';

  /**
   * The bundle this mapping applies to.
   *
   * @var string
   */
  protected $target_bundle = '';

  /**
   * The field holding the IFSC code.
   *
   * @var string
   */
  protected $source_field = '';

  /**
   * Field machine names keyed by token name.
   *
   * @var array
   */
  protected $targets = [];

  /**
   * Overwrite behaviour.
   *
   * @var string
   */
  protected $overwrite = IfscMappingInterface::OVERWRITE_EMPTY;

  /**
   * Whether target fields are rendered read only.
   *
   * @var bool
   */
  protected $lock_targets = FALSE;

  /**
   * {@inheritdoc}
   */
  public function getTargetEntityTypeId(): string {
    return (string) $this->target_entity_type;
  }

  /**
   * {@inheritdoc}
   */
  public function getTargetBundle(): string {
    return (string) $this->target_bundle;
  }

  /**
   * {@inheritdoc}
   */
  public function getSourceField(): string {
    return (string) $this->source_field;
  }

  /**
   * {@inheritdoc}
   */
  public function getTargets(): array {
    $targets = [];
    foreach ((array) $this->targets as $token => $field_name) {
      if (is_string($field_name) && $field_name !== '') {
        $targets[$token] = $field_name;
      }
    }
    return $targets;
  }

  /**
   * {@inheritdoc}
   */
  public function getOverwrite(): string {
    return $this->overwrite === IfscMappingInterface::OVERWRITE_ALWAYS
      ? IfscMappingInterface::OVERWRITE_ALWAYS
      : IfscMappingInterface::OVERWRITE_EMPTY;
  }

  /**
   * {@inheritdoc}
   */
  public function lockTargets(): bool {
    return (bool) $this->lock_targets;
  }

  /**
   * {@inheritdoc}
   */
  public function calculateDependencies() {
    parent::calculateDependencies();

    $definition = $this->entityTypeManager()
      ->getDefinition($this->getTargetEntityTypeId(), FALSE);

    if ($definition !== NULL && $definition->getProvider() !== 'core') {
      $this->addDependency('module', $definition->getProvider());
    }

    return $this;
  }

}
