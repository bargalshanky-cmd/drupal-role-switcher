/**
 * @file
 * Resolves an IFSC code and fills the fields tagged by the active mapping.
 */

((Drupal, drupalSettings, once) => {
  'use strict';

  const PATTERN = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  const FILLED_FLAG = 'ifscAutofilled';

  /**
   * Reads module settings, falling back to safe defaults.
   *
   * @return {object}
   *   The settings object.
   */
  function config() {
    return drupalSettings.ifscAutofill || {};
  }

  /**
   * Strips separators and upper cases the value.
   *
   * @param {string} value
   *   Raw input.
   *
   * @return {string}
   *   The normalised code.
   */
  function normalise(value) {
    return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  }

  /**
   * Builds the lookup URL for a code.
   *
   * @param {string} code
   *   A normalised code.
   *
   * @return {string}
   *   The absolute path to request.
   */
  function endpoint(code) {
    const settings = config();
    return settings.endpointTemplate.replace(
      settings.placeholder,
      encodeURIComponent(code)
    );
  }

  /**
   * Creates the status line shown under the source input.
   *
   * @param {HTMLElement} input
   *   The IFSC input.
   *
   * @return {HTMLElement}
   *   The status element.
   */
  function buildStatus(input) {
    const status = document.createElement('div');
    status.className = 'ifsc-autofill-status';
    status.setAttribute('aria-live', 'polite');
    status.hidden = true;

    const anchor = input.closest('.js-form-item') || input;
    anchor.appendChild(status);

    return status;
  }

  /**
   * Updates the status line.
   *
   * @param {HTMLElement} status
   *   The status element.
   * @param {string} state
   *   One of "loading", "success", "error" or "idle".
   * @param {string} message
   *   The text to show.
   */
  function setStatus(status, state, message) {
    status.className = `ifsc-autofill-status ifsc-autofill-status--${state}`;
    status.textContent = message || '';
    status.hidden = !message;

    if (state === 'error' || state === 'success') {
      Drupal.announce(message);
    }
  }

  /**
   * Target inputs belonging to the same mapping as the source input.
   *
   * @param {HTMLElement} input
   *   The IFSC input.
   *
   * @return {HTMLElement[]}
   *   The target inputs.
   */
  function findTargets(input) {
    const group = input.getAttribute('data-ifsc-source');
    const scope = input.closest('form') || document;

    return Array.prototype.slice.call(
      scope.querySelectorAll('[data-ifsc-target][data-ifsc-group]')
    ).filter((element) => element.getAttribute('data-ifsc-group') === group);
  }

  /**
   * Writes a value into a target element and notifies other scripts.
   *
   * @param {HTMLElement} element
   *   The target input or select.
   * @param {string} value
   *   The value to write.
   *
   * @return {boolean}
   *   TRUE when the value was applied.
   */
  function applyValue(element, value) {
    if (element.tagName === 'SELECT') {
      const wanted = String(value).toLowerCase();
      const option = Array.prototype.slice.call(element.options).find(
        (candidate) =>
          candidate.value === value ||
          candidate.text.trim().toLowerCase() === wanted
      );

      if (!option) {
        return false;
      }

      element.value = option.value;
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));

    return true;
  }

  /**
   * Clears the targets this script filled earlier.
   *
   * @param {HTMLElement[]} targets
   *   The target inputs.
   */
  function clearFilled(targets) {
    targets.forEach((element) => {
      if (element.dataset[FILLED_FLAG] === '1') {
        delete element.dataset[FILLED_FLAG];
        applyValue(element, '');
      }
    });
  }

  /**
   * Fills the targets from a lookup result.
   *
   * @param {HTMLElement} input
   *   The IFSC input.
   * @param {object} data
   *   Token keyed values.
   *
   * @return {number}
   *   How many fields were filled.
   */
  function fill(input, data) {
    const overwriteAll = input.getAttribute('data-ifsc-overwrite') === 'always';
    let filled = 0;

    findTargets(input).forEach((element) => {
      const token = element.getAttribute('data-ifsc-target');
      const value = data[token];

      if (value === undefined || value === null || value === '') {
        return;
      }

      const isEmpty = String(element.value || '').trim() === '';
      const wasAutofilled = element.dataset[FILLED_FLAG] === '1';

      if (!overwriteAll && !isEmpty && !wasAutofilled) {
        return;
      }

      // Locked fields are readonly, which does not stop a scripted write.
      if (applyValue(element, value)) {
        element.dataset[FILLED_FLAG] = '1';
        filled += 1;
      }
    });

    return filled;
  }

  /**
   * Requests bank details and updates the form.
   *
   * @param {HTMLElement} input
   *   The IFSC input.
   * @param {object} state
   *   Per input state holding the in-flight request and last code.
   * @param {HTMLElement} status
   *   The status element.
   */
  function lookup(input, state, status) {
    const code = normalise(input.value);

    if (code !== input.value) {
      input.value = code;
    }

    if (code === '') {
      state.last = null;
      clearFilled(findTargets(input));
      setStatus(status, 'idle', '');
      return;
    }

    if (!PATTERN.test(code)) {
      state.last = null;
      setStatus(
        status,
        'error',
        Drupal.t('An IFSC code is 11 characters, for example SBIN0030381.')
      );
      return;
    }

    if (state.last === code) {
      return;
    }

    if (state.request) {
      state.request.abort();
    }

    const controller = new AbortController();
    state.request = controller;

    setStatus(status, 'loading', Drupal.t('Looking up bank details…'));

    fetch(endpoint(code), {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
      credentials: 'same-origin',
    })
      .then((response) =>
        response.json().then((body) => ({ ok: response.ok, body }))
      )
      .then(({ ok, body }) => {
        state.request = null;

        if (!ok || !body.data) {
          state.last = null;
          setStatus(
            status,
            'error',
            body.message ||
              Drupal.t('Bank details could not be loaded. Fill the fields manually.')
          );
          return;
        }

        state.last = code;
        const filled = fill(input, body.data);

        if (filled === 0) {
          setStatus(
            status,
            'success',
            Drupal.t('@bank, @branch. Existing values were kept.', {
              '@bank': body.data.BANK,
              '@branch': body.data.BRANCH,
            })
          );
          return;
        }

        setStatus(
          status,
          'success',
          Drupal.t('@bank, @branch.', {
            '@bank': body.data.BANK,
            '@branch': body.data.BRANCH,
          })
        );
      })
      .catch((error) => {
        if (error.name === 'AbortError') {
          return;
        }

        state.request = null;
        state.last = null;
        setStatus(
          status,
          'error',
          Drupal.t('Bank details could not be loaded. Fill the fields manually.')
        );
      });
  }

  Drupal.behaviors.ifscAutofill = {
    attach(context) {
      const settings = config();

      if (!settings.endpointTemplate) {
        return;
      }

      const debounce = Number.isFinite(settings.debounce)
        ? settings.debounce
        : 500;

      once('ifsc-autofill', '[data-ifsc-source]', context).forEach((input) => {
        const state = { request: null, last: null, timer: null };
        const status = buildStatus(input);
        const run = () => {
          window.clearTimeout(state.timer);
          lookup(input, state, status);
        };

        input.addEventListener('blur', run);

        input.addEventListener('input', () => {
          window.clearTimeout(state.timer);
          state.timer = window.setTimeout(run, debounce);
        });

        input.addEventListener('keydown', (event) => {
          if (event.key === 'Enter') {
            // Resolve the code instead of submitting a half filled form.
            event.preventDefault();
            run();
          }
        });
      });
    },
  };
})(Drupal, drupalSettings, once);
