<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Defines an IFSC autofill mapping.
 */
interface IfscMappingInterface extends ConfigEntityInterface {

  /**
   * Only fill a target field that is currently empty.
   */
  public const OVERWRITE_EMPTY = 'empty';

  /**
   * Always replace the target field value.
   */
  public const OVERWRITE_ALWAYS = 'always';

  /**
   * The entity type this mapping applies to.
   *
   * @return string
   *   An entity type ID.
   */
  public function getTargetEntityTypeId(): string;

  /**
   * The bundle this mapping applies to.
   *
   * @return string
   *   A bundle name.
   */
  public function getTargetBundle(): string;

  /**
   * The field holding the IFSC code.
   *
   * @return string
   *   A field machine name.
   */
  public function getSourceField(): string;

  /**
   * Fields that receive looked up values.
   *
   * @return array<string, string>
   *   Field machine names keyed by token name, empty values removed.
   */
  public function getTargets(): array;

  /**
   * How existing target values are treated.
   *
   * @return string
   *   Either self::OVERWRITE_EMPTY or self::OVERWRITE_ALWAYS.
   */
  public function getOverwrite(): string;

  /**
   * Whether target fields are rendered read only.
   *
   * @return bool
   *   TRUE when targets should not be hand edited.
   */
  public function lockTargets(): bool;

}
