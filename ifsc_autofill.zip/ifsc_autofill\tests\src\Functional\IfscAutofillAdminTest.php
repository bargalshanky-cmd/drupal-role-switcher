<?php

declare(strict_types=1);

namespace Drupal\Tests\ifsc_autofill\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\ifsc_autofill\Entity\IfscMapping;
use Drupal\ifsc_autofill\IfscMappingInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

/**
 * Covers the administration screens and the form attachment.
 *
 * @group ifsc_autofill
 */
class IfscAutofillAdminTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['node', 'field', 'ifsc_autofill'];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->drupalCreateContentType(['type' => 'vendor', 'name' => 'Vendor']);

    foreach (['field_ifsc', 'field_bank_name', 'field_branch_name'] as $field_name) {
      FieldStorageConfig::create([
        'field_name' => $field_name,
        'entity_type' => 'node',
        'type' => 'string',
      ])->save();

      FieldConfig::create([
        'field_name' => $field_name,
        'entity_type' => 'node',
        'bundle' => 'vendor',
        'label' => ucwords(str_replace(['field_', '_'], ['', ' '], $field_name)),
      ])->save();

      $this->container->get('entity_display.repository')
        ->getFormDisplay('node', 'vendor')
        ->setComponent($field_name, ['type' => 'string_textfield'])
        ->save();
    }
  }

  /**
   * The settings form saves and the mapping list reflects stored entities.
   */
  public function testAdministrationScreens(): void {
    $this->drupalLogin($this->drupalCreateUser(['administer ifsc autofill']));

    $this->drupalGet('/admin/config/services/ifsc-autofill');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->fieldValueEquals('endpoint', 'https://ifsc.razorpay.com');

    $this->submitForm([
      'endpoint' => 'https://ifsc.example.com/',
      'timeout' => 8,
      'cache_max_age' => 1000,
      'negative_cache_max_age' => 100,
      'flood_limit' => 5,
      'flood_window' => 30,
      'debounce' => 250,
    ], 'Save configuration');

    $config = $this->config('ifsc_autofill.settings');
    $this->assertSame('https://ifsc.example.com', $config->get('endpoint'), 'The trailing slash is normalised away.');
    $this->assertSame(8, $config->get('timeout'));
    $this->assertSame(5, $config->get('flood_limit'));

    $this->drupalGet('/admin/config/services/ifsc-autofill/mappings');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('No mappings yet.');

    $this->createMapping();

    $this->drupalGet('/admin/config/services/ifsc-autofill/mappings');
    $this->assertSession()->pageTextContains('Vendor bank details');
    $this->assertSession()->pageTextContains('field_ifsc');
    $this->assertSession()->pageTextContains('2 fields');
  }

  /**
   * An editor without the permission gets no autofill markup and no endpoint.
   */
  public function testPermissionGatesTheFeature(): void {
    $this->createMapping();

    $this->drupalLogin($this->drupalCreateUser(['create vendor content']));
    $this->drupalGet('/node/add/vendor');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->responseNotContains('data-ifsc-source');

    $this->drupalGet('/ifsc-autofill/lookup/SBIN0030381');
    $this->assertSession()->statusCodeEquals(403);
  }

  /**
   * A permitted editor sees the source and target fields tagged for the script.
   */
  public function testFormsAreTagged(): void {
    $this->createMapping();

    $this->drupalLogin($this->drupalCreateUser([
      'create vendor content',
      'use ifsc autofill',
    ]));

    $this->drupalGet('/node/add/vendor');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->responseContains('data-ifsc-source="vendor_bank"');
    $this->assertSession()->responseContains('data-ifsc-target="BANK"');
    $this->assertSession()->responseContains('data-ifsc-target="BRANCH"');
  }

  /**
   * A disabled mapping does not touch the form.
   */
  public function testDisabledMappingIsIgnored(): void {
    $mapping = $this->createMapping();
    $mapping->disable()->save();

    $this->drupalLogin($this->drupalCreateUser([
      'create vendor content',
      'use ifsc autofill',
    ]));

    $this->drupalGet('/node/add/vendor');
    $this->assertSession()->responseNotContains('data-ifsc-source');
  }

  /**
   * Creates the mapping used across the test methods.
   *
   * @return \Drupal\ifsc_autofill\IfscMappingInterface
   *   The saved mapping.
   */
  protected function createMapping(): IfscMappingInterface {
    $mapping = IfscMapping::create([
      'id' => 'vendor_bank',
      'label' => 'Vendor bank details',
      'status' => TRUE,
      'target_entity_type' => 'node',
      'target_bundle' => 'vendor',
      'source_field' => 'field_ifsc',
      'targets' => [
        'BANK' => 'field_bank_name',
        'BRANCH' => 'field_branch_name',
      ],
      'overwrite' => IfscMappingInterface::OVERWRITE_EMPTY,
      'lock_targets' => FALSE,
    ]);
    $mapping->save();

    return $mapping;
  }

}
