<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Service;

/**
 * Resolves an IFSC code into bank details.
 */
interface IfscClientInterface {

  /**
   * Cache tag invalidated when stored lookups should be dropped.
   */
  public const CACHE_TAG = 'ifsc_autofill:lookup';

  /**
   * Looks up a code.
   *
   * @param string $ifsc
   *   The code, in any casing and with optional separators.
   *
   * @return array<string, string>|null
   *   Token keyed values, or NULL when the code does not exist.
   *
   * @throws \Drupal\ifsc_autofill\Exception\IfscLookupException
   *   When the code is malformed or the upstream service failed.
   */
  public function lookup(string $ifsc): ?array;

  /**
   * Strips separators and upper cases a code.
   *
   * @param string $ifsc
   *   The raw input.
   *
   * @return string
   *   The normalised code.
   */
  public function normalize(string $ifsc): string;

  /**
   * Checks a normalised code against the IFSC format.
   *
   * @param string $ifsc
   *   The normalised code.
   *
   * @return bool
   *   TRUE when the code is well formed.
   */
  public function isValid(string $ifsc): bool;

}
