<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Form;

use Drupal\Core\Entity\EntityConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Confirmation form for deleting an IFSC mapping.
 */
class IfscMappingDeleteForm extends EntityConfirmFormBase {

  /**
   * {@inheritdoc}
   */
  public function getQuestion(): string {
    return (string) $this->t('Delete the %label mapping?', [
      '%label' => $this->entity->label(),
    ]);
  }

  /**
   * {@inheritdoc}
   */
  public function getDescription(): string {
    return (string) $this->t('Forms covered by this mapping stop filling bank details automatically. Field values already saved are not touched.');
  }

  /**
   * {@inheritdoc}
   */
  public function getConfirmText(): string {
    return (string) $this->t('Delete');
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl(): Url {
    return new Url('entity.ifsc_mapping.collection');
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $label = $this->entity->label();
    $this->entity->delete();

    $this->messenger()->addStatus($this->t('Deleted the %label mapping.', [
      '%label' => $label,
    ]));
    $form_state->setRedirectUrl($this->getCancelUrl());
  }

}
