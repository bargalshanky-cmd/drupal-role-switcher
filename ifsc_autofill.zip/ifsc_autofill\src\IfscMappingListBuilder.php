<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Url;

/**
 * Lists the configured IFSC mappings.
 */
class IfscMappingListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['label'] = $this->t('Mapping');
    $header['target'] = $this->t('Applies to');
    $header['source'] = $this->t('IFSC field');
    $header['targets'] = $this->t('Filled fields');
    $header['status'] = $this->t('Status');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof IfscMappingInterface);

    $row['label'] = $entity->label();
    $row['target'] = $entity->getTargetEntityTypeId() . ' : ' . $entity->getTargetBundle();
    $row['source'] = $entity->getSourceField();
    $row['targets'] = $this->formatPlural(
      count($entity->getTargets()),
      '1 field',
      '@count fields'
    );
    $row['status'] = $entity->status() ? $this->t('Enabled') : $this->t('Disabled');

    return $row + parent::buildRow($entity);
  }

  /**
   * {@inheritdoc}
   */
  public function render(): array {
    $build = parent::render();

    $build['table']['#empty'] = $this->t('No mappings yet. <a href=":url">Add one</a> to start filling bank details automatically.', [
      ':url' => Url::fromRoute('entity.ifsc_mapping.add_form')->toString(),
    ]);
    $build['#attached']['library'][] = 'ifsc_autofill/admin';

    return $build;
  }

}
