<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Form;

use Drupal\Core\Entity\ContentEntityTypeInterface;
use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\ifsc_autofill\IfscMappingInterface;
use Drupal\ifsc_autofill\IfscTokens;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Add and edit form for IFSC mappings.
 */
class IfscMappingForm extends EntityForm {

  /**
   * Wrapper ID for the entity type dependent part of the form.
   */
  protected const WRAPPER = 'ifsc-mapping-scope';

  /**
   * Field types that can hold a looked up value.
   */
  protected const SUPPORTED_FIELD_TYPES = [
    'string',
    'string_long',
    'list_string',
    'telephone',
    'email',
  ];

  /**
   * Constructs the form.
   *
   * @param \Drupal\Core\Entity\EntityTypeBundleInfoInterface $bundleInfo
   *   Bundle information.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $fieldManager
   *   The entity field manager.
   */
  public function __construct(
    protected readonly EntityTypeBundleInfoInterface $bundleInfo,
    protected readonly EntityFieldManagerInterface $fieldManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('entity_type.bundle.info'),
      $container->get('entity_field.manager'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state): array {
    $form = parent::form($form, $form_state);

    /** @var \Drupal\ifsc_autofill\IfscMappingInterface $mapping */
    $mapping = $this->entity;

    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#description' => $this->t('Shown in the mapping list only, for example "Vendor bank details".'),
      '#default_value' => $mapping->label(),
      '#required' => TRUE,
      '#maxlength' => 128,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $mapping->id(),
      '#machine_name' => [
        'exists' => [$this, 'mappingExists'],
        'source' => ['label'],
      ],
      '#disabled' => !$mapping->isNew(),
    ];

    $entity_type_options = $this->getEntityTypeOptions();
    $entity_type_id = $this->currentEntityTypeId($form_state, $entity_type_options);

    $form['target_entity_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Entity type'),
      '#options' => $entity_type_options,
      '#default_value' => $entity_type_id,
      '#required' => TRUE,
      '#empty_option' => $this->t('- Select -'),
      '#ajax' => [
        'callback' => '::refreshScope',
        'wrapper' => self::WRAPPER,
      ],
    ];

    $form['scope'] = [
      '#type' => 'container',
      '#attributes' => ['id' => self::WRAPPER],
      '#tree' => FALSE,
    ];

    if ($entity_type_id === '') {
      $form['scope']['hint'] = [
        '#markup' => '<p>' . $this->t('Choose an entity type to continue.') . '</p>',
      ];

      return $this->finishForm($form, $mapping);
    }

    $bundle_options = $this->getBundleOptions($entity_type_id);
    $bundle = $this->currentBundle($form_state, $entity_type_id, $bundle_options);

    $form['scope']['target_bundle'] = [
      '#type' => 'select',
      '#title' => $this->t('Bundle'),
      '#options' => $bundle_options,
      '#default_value' => $bundle,
      '#required' => TRUE,
      '#empty_option' => $this->t('- Select -'),
      '#ajax' => [
        'callback' => '::refreshScope',
        'wrapper' => self::WRAPPER,
      ],
    ];

    if ($bundle === '') {
      return $this->finishForm($form, $mapping);
    }

    $field_options = $this->getFieldOptions($entity_type_id, $bundle);

    if (count($field_options) < 2) {
      $form['scope']['warning'] = [
        '#theme' => 'status_messages',
        '#message_list' => [
          'warning' => [
            $this->t('This bundle needs at least two plain text fields: one for the IFSC code and one to receive a value.'),
          ],
        ],
      ];

      return $this->finishForm($form, $mapping);
    }

    $form['scope']['source_field'] = [
      '#type' => 'select',
      '#title' => $this->t('IFSC code field'),
      '#description' => $this->t('The field the editor types the code into.'),
      '#options' => $field_options,
      '#default_value' => $this->currentValue($form_state, 'source_field', $mapping->getSourceField(), $field_options),
      '#required' => TRUE,
      '#empty_option' => $this->t('- Select -'),
    ];

    $form['scope']['targets'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Fields to fill'),
      '#description' => $this->t('Leave a value empty to ignore it. Only plain text, long text, list (text), telephone and email fields are offered, because they can hold a value without extra processing.'),
      '#tree' => TRUE,
    ];

    $saved_targets = $mapping->getTargets();
    foreach (IfscTokens::definitions() as $token => $label) {
      $form['scope']['targets'][$token] = [
        '#type' => 'select',
        '#title' => $label,
        '#options' => $field_options,
        '#empty_option' => $this->t('- Do not fill -'),
        '#default_value' => $this->currentValue(
          $form_state,
          ['targets', $token],
          $saved_targets[$token] ?? '',
          $field_options
        ),
      ];
    }

    $form['scope']['behaviour'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Behaviour'),
    ];

    $form['scope']['behaviour']['overwrite'] = [
      '#type' => 'radios',
      '#title' => $this->t('When a field already has a value'),
      '#options' => [
        IfscMappingInterface::OVERWRITE_EMPTY => $this->t('Keep what the editor typed'),
        IfscMappingInterface::OVERWRITE_ALWAYS => $this->t('Replace it with the looked up value'),
      ],
      '#default_value' => $mapping->getOverwrite(),
    ];

    $form['scope']['behaviour']['lock_targets'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Make the filled fields read only'),
      '#description' => $this->t('Prevents hand editing of text inputs. Select lists stay editable because a read only select cannot be enforced in the browser.'),
      '#default_value' => $mapping->lockTargets(),
    ];

    return $this->finishForm($form, $mapping);
  }

  /**
   * Adds the fields that are always present.
   *
   * @param array $form
   *   The form so far.
   * @param \Drupal\ifsc_autofill\IfscMappingInterface $mapping
   *   The mapping being edited.
   *
   * @return array
   *   The completed form.
   */
  protected function finishForm(array $form, IfscMappingInterface $mapping): array {
    $form['status'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enabled'),
      '#description' => $this->t('Disabled mappings stay configured but do nothing.'),
      '#default_value' => $mapping->isNew() ? TRUE : $mapping->status(),
      '#weight' => 100,
    ];

    $form['#attached']['library'][] = 'ifsc_autofill/admin';

    return $form;
  }

  /**
   * AJAX callback returning the entity type dependent part of the form.
   *
   * @param array $form
   *   The form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The replacement render array.
   */
  public function refreshScope(array &$form, FormStateInterface $form_state): array {
    return $form['scope'];
  }

  /**
   * Checks whether a mapping ID is taken.
   *
   * @param string $id
   *   The candidate machine name.
   *
   * @return bool
   *   TRUE when a mapping with that ID exists.
   */
  public function mappingExists(string $id): bool {
    return (bool) $this->entityTypeManager
      ->getStorage('ifsc_mapping')
      ->load($id);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): array {
    $form = parent::validateForm($form, $form_state);

    $source = (string) $form_state->getValue('source_field');
    $targets = array_filter((array) $form_state->getValue('targets'));

    if ($source === '') {
      return $form;
    }

    if ($targets === []) {
      $form_state->setErrorByName('targets', $this->t('Choose at least one field to fill.'));
      return $form;
    }

    if (in_array($source, $targets, TRUE)) {
      $form_state->setErrorByName('source_field', $this->t('The IFSC field cannot also be a target field.'));
    }

    $duplicates = array_diff_assoc($targets, array_unique($targets));
    if ($duplicates !== []) {
      $form_state->setErrorByName('targets', $this->t('Each field can only receive one value. Reused: @fields', [
        '@fields' => implode(', ', array_unique($duplicates)),
      ]));
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state): int {
    /** @var \Drupal\ifsc_autofill\IfscMappingInterface $mapping */
    $mapping = $this->entity;
    $mapping->set('targets', array_filter((array) $form_state->getValue('targets')));

    $result = $mapping->save();

    $this->messenger()->addStatus($this->t('Saved the %label mapping.', [
      '%label' => $mapping->label(),
    ]));
    $form_state->setRedirectUrl($mapping->toUrl('collection'));

    return $result;
  }

  /**
   * Content entity types that can carry fields.
   *
   * @return array<string, string>
   *   Entity type labels keyed by ID.
   */
  protected function getEntityTypeOptions(): array {
    $options = [];

    foreach ($this->entityTypeManager->getDefinitions() as $id => $definition) {
      if (!$definition instanceof ContentEntityTypeInterface) {
        continue;
      }
      // Skip entity types that have no editable form at all.
      $handlers = $definition->getHandlerClasses();
      if (empty($handlers['form'])) {
        continue;
      }
      $options[$id] = (string) $definition->getLabel();
    }

    asort($options);

    return $options;
  }

  /**
   * Bundles of an entity type.
   *
   * @param string $entity_type_id
   *   The entity type ID.
   *
   * @return array<string, string>
   *   Bundle labels keyed by machine name.
   */
  protected function getBundleOptions(string $entity_type_id): array {
    $options = [];

    foreach ($this->bundleInfo->getBundleInfo($entity_type_id) as $bundle => $info) {
      $options[$bundle] = (string) ($info['label'] ?? $bundle);
    }

    asort($options);

    return $options;
  }

  /**
   * Fields of a bundle that can hold a looked up value.
   *
   * @param string $entity_type_id
   *   The entity type ID.
   * @param string $bundle
   *   The bundle.
   *
   * @return array<string, string>
   *   Field labels keyed by machine name.
   */
  protected function getFieldOptions(string $entity_type_id, string $bundle): array {
    $options = [];

    foreach ($this->fieldManager->getFieldDefinitions($entity_type_id, $bundle) as $name => $definition) {
      if (!in_array($definition->getType(), self::SUPPORTED_FIELD_TYPES, TRUE)) {
        continue;
      }
      if ($definition->isReadOnly() || $definition->isComputed()) {
        continue;
      }

      $options[$name] = $this->t('@label (@name)', [
        '@label' => $definition->getLabel(),
        '@name' => $name,
      ]);
    }

    ksort($options);

    return $options;
  }

  /**
   * Resolves the entity type currently in play.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $options
   *   Valid entity type options.
   *
   * @return string
   *   An entity type ID, or an empty string.
   */
  protected function currentEntityTypeId(FormStateInterface $form_state, array $options): string {
    $value = $form_state->getValue('target_entity_type');

    if ($value === NULL) {
      /** @var \Drupal\ifsc_autofill\IfscMappingInterface $mapping */
      $mapping = $this->entity;
      $value = $mapping->getTargetEntityTypeId();
    }

    $value = (string) $value;

    return isset($options[$value]) ? $value : '';
  }

  /**
   * Resolves the bundle currently in play.
   *
   * A stale bundle is discarded when the entity type changes.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $entity_type_id
   *   The selected entity type.
   * @param array $options
   *   Valid bundle options.
   *
   * @return string
   *   A bundle name, or an empty string.
   */
  protected function currentBundle(FormStateInterface $form_state, string $entity_type_id, array $options): string {
    /** @var \Drupal\ifsc_autofill\IfscMappingInterface $mapping */
    $mapping = $this->entity;

    $value = $form_state->getValue('target_bundle');
    if ($value === NULL && $mapping->getTargetEntityTypeId() === $entity_type_id) {
      $value = $mapping->getTargetBundle();
    }

    $value = (string) $value;

    return isset($options[$value]) ? $value : '';
  }

  /**
   * Resolves a field select value, discarding values from another bundle.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string|array $key
   *   The form state key or parents.
   * @param string $saved
   *   The value stored on the entity.
   * @param array $options
   *   Valid field options.
   *
   * @return string
   *   A field name, or an empty string.
   */
  protected function currentValue(FormStateInterface $form_state, string|array $key, string $saved, array $options): string {
    $value = $form_state->getValue($key);
    $value = $value === NULL ? $saved : (string) $value;

    return isset($options[$value]) ? $value : '';
  }

}
