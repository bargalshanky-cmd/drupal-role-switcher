<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Service;

use Drupal\ifsc_autofill\IfscMappingInterface;

/**
 * Finds the mapping that applies to an entity form.
 */
interface IfscMappingManagerInterface {

  /**
   * Returns the enabled mapping for an entity type and bundle.
   *
   * @param string $entity_type_id
   *   The entity type ID.
   * @param string $bundle
   *   The bundle.
   *
   * @return \Drupal\ifsc_autofill\IfscMappingInterface|null
   *   The mapping, or NULL when none applies.
   */
  public function getMapping(string $entity_type_id, string $bundle): ?IfscMappingInterface;

}
