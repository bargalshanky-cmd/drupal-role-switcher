<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Service;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\ifsc_autofill\Exception\IfscLookupException;
use Drupal\ifsc_autofill\IfscTokens;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Log\LoggerInterface;

/**
 * Talks to an IFSC directory and caches the answers.
 *
 * The default endpoint is Razorpay's public, unauthenticated IFSC service. Any
 * host that answers `GET {endpoint}/{IFSC}` with the same JSON shape works, so
 * a site can point this at an internal mirror instead.
 */
class IfscClient implements IfscClientInterface {

  use StringTranslationTrait;

  /**
   * Marker stored for codes the directory does not know.
   */
  protected const NOT_FOUND = '__ifsc_not_found__';

  /**
   * Constructs the client.
   *
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   The HTTP client.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache
   *   The lookup cache bin.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Psr\Log\LoggerInterface $logger
   *   The module logger channel.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   The time service.
   */
  public function __construct(
    protected readonly ClientInterface $httpClient,
    protected readonly CacheBackendInterface $cache,
    protected readonly ConfigFactoryInterface $configFactory,
    protected readonly LoggerInterface $logger,
    protected readonly TimeInterface $time,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function normalize(string $ifsc): string {
    return preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($ifsc))) ?? '';
  }

  /**
   * {@inheritdoc}
   */
  public function isValid(string $ifsc): bool {
    return (bool) preg_match(IfscTokens::PATTERN, $ifsc);
  }

  /**
   * {@inheritdoc}
   */
  public function lookup(string $ifsc): ?array {
    $code = $this->normalize($ifsc);

    if (!$this->isValid($code)) {
      throw new IfscLookupException(
        (string) $this->t('Enter an 11 character IFSC code, for example SBIN0030381.'),
        'invalid',
        400
      );
    }

    $cid = 'ifsc:' . $code;
    $cached = $this->cache->get($cid);
    if ($cached !== FALSE) {
      return $cached->data === self::NOT_FOUND ? NULL : $cached->data;
    }

    $settings = $this->configFactory->get('ifsc_autofill.settings');
    $endpoint = rtrim((string) $settings->get('endpoint'), '/');
    $timeout = max(1, (int) $settings->get('timeout'));

    if ($endpoint === '') {
      throw new IfscLookupException(
        (string) $this->t('No IFSC lookup endpoint is configured.'),
        'unconfigured',
        503
      );
    }

    try {
      $response = $this->httpClient->request('GET', $endpoint . '/' . $code, [
        'timeout' => $timeout,
        'connect_timeout' => $timeout,
        'headers' => ['Accept' => 'application/json'],
      ]);
    }
    catch (ClientException $e) {
      // A 404 is the directory's way of saying the code does not exist. Cache
      // that answer briefly so typos do not hammer the upstream service.
      if ($e->getResponse()->getStatusCode() === 404) {
        $this->cacheResult($cid, self::NOT_FOUND, (int) $settings->get('negative_cache_max_age'));
        return NULL;
      }

      $this->logger->warning('IFSC lookup for @code rejected with status @status.', [
        '@code' => $code,
        '@status' => $e->getResponse()->getStatusCode(),
      ]);

      throw new IfscLookupException(
        (string) $this->t('The bank directory rejected the request.'),
        'unavailable',
        502,
        $e
      );
    }
    catch (GuzzleException $e) {
      $this->logger->error('IFSC lookup for @code failed: @message', [
        '@code' => $code,
        '@message' => $e->getMessage(),
      ]);

      throw new IfscLookupException(
        (string) $this->t('The bank directory could not be reached. Fill the fields manually or try again.'),
        'unavailable',
        502,
        $e
      );
    }

    $payload = json_decode((string) $response->getBody(), TRUE);

    if (!is_array($payload) || empty($payload['IFSC'])) {
      $this->cacheResult($cid, self::NOT_FOUND, (int) $settings->get('negative_cache_max_age'));
      return NULL;
    }

    $result = $this->extract($payload, $code);
    $this->cacheResult($cid, $result, (int) $settings->get('cache_max_age'));

    return $result;
  }

  /**
   * Reduces a raw response to the supported tokens.
   *
   * @param array $payload
   *   The decoded response.
   * @param string $code
   *   The normalised code that was requested.
   *
   * @return array<string, string>
   *   Token keyed strings, every supported token present.
   */
  protected function extract(array $payload, string $code): array {
    $result = [];

    foreach (IfscTokens::names() as $token) {
      $value = $payload[$token] ?? '';

      if (is_bool($value)) {
        $value = $value ? (string) $this->t('Yes') : (string) $this->t('No');
      }
      elseif (!is_scalar($value)) {
        $value = '';
      }

      $result[$token] = trim((string) $value);
    }

    // Always answer with the code we actually resolved.
    $result['IFSC'] = $code;

    return $result;
  }

  /**
   * Stores a lookup result.
   *
   * @param string $cid
   *   The cache ID.
   * @param mixed $data
   *   The value to store.
   * @param int $max_age
   *   Lifetime in seconds. Zero or less skips caching.
   */
  protected function cacheResult(string $cid, mixed $data, int $max_age): void {
    if ($max_age <= 0) {
      return;
    }

    $this->cache->set(
      $cid,
      $data,
      $this->time->getRequestTime() + $max_age,
      [self::CACHE_TAG]
    );
  }

}
