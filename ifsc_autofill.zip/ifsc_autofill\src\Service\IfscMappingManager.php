<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\ifsc_autofill\IfscMappingInterface;

/**
 * Looks up mappings by entity type and bundle, with a per request cache.
 */
class IfscMappingManager implements IfscMappingManagerInterface {

  /**
   * Resolved mappings keyed by "entity_type:bundle".
   *
   * @var array<string, \Drupal\ifsc_autofill\IfscMappingInterface|null>
   */
  protected array $resolved = [];

  /**
   * Constructs the manager.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function getMapping(string $entity_type_id, string $bundle): ?IfscMappingInterface {
    $key = $entity_type_id . ':' . $bundle;

    if (array_key_exists($key, $this->resolved)) {
      return $this->resolved[$key];
    }

    $matches = $this->entityTypeManager
      ->getStorage('ifsc_mapping')
      ->loadByProperties([
        'target_entity_type' => $entity_type_id,
        'target_bundle' => $bundle,
        'status' => TRUE,
      ]);

    $mapping = NULL;
    foreach ($matches as $candidate) {
      if ($candidate instanceof IfscMappingInterface && $candidate->getSourceField() !== '') {
        $mapping = $candidate;
        break;
      }
    }

    return $this->resolved[$key] = $mapping;
  }

}
