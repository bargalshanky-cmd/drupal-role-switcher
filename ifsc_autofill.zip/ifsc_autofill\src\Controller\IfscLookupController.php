<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Controller;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Flood\FloodInterface;
use Drupal\ifsc_autofill\Exception\IfscLookupException;
use Drupal\ifsc_autofill\Service\IfscClientInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Serves IFSC lookups to the autofill JavaScript.
 */
class IfscLookupController extends ControllerBase {

  /**
   * Flood control event name.
   */
  protected const FLOOD_EVENT = 'ifsc_autofill.lookup';

  /**
   * Constructs the controller.
   *
   * @param \Drupal\ifsc_autofill\Service\IfscClientInterface $client
   *   The IFSC client.
   * @param \Drupal\Core\Flood\FloodInterface $flood
   *   Flood control.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   */
  public function __construct(
    protected readonly IfscClientInterface $client,
    protected readonly FloodInterface $flood,
    ConfigFactoryInterface $configFactory,
  ) {
    $this->configFactory = $configFactory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('ifsc_autofill.client'),
      $container->get('flood'),
      $container->get('config.factory'),
    );
  }

  /**
   * Returns bank details for an IFSC code.
   *
   * @param string $ifsc
   *   The code from the request path.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   A JSON response carrying either "data" or "error" and "message".
   */
  public function lookup(string $ifsc): JsonResponse {
    $settings = $this->config('ifsc_autofill.settings');
    $limit = (int) $settings->get('flood_limit');
    $window = max(1, (int) $settings->get('flood_window'));

    if ($limit > 0) {
      $identifier = $this->currentUser()->isAuthenticated()
        ? 'uid:' . $this->currentUser()->id()
        : NULL;

      if (!$this->flood->isAllowed(self::FLOOD_EVENT, $limit, $window, $identifier)) {
        return $this->error(
          'rate_limited',
          (string) $this->t('Too many lookups. Wait a moment and try again.'),
          429
        );
      }

      $this->flood->register(self::FLOOD_EVENT, $window, $identifier);
    }

    try {
      $data = $this->client->lookup($ifsc);
    }
    catch (IfscLookupException $e) {
      return $this->error($e->getReason(), $e->getMessage(), $e->getStatusCode());
    }

    if ($data === NULL) {
      return $this->error(
        'not_found',
        (string) $this->t('No bank found for that IFSC code.'),
        404
      );
    }

    $response = new JsonResponse(['data' => $data]);
    // The result is already cached server side; let the browser reuse it too.
    $response->setPrivate();
    $response->setMaxAge(300);

    return $response;
  }

  /**
   * Builds an error response.
   *
   * @param string $reason
   *   Machine readable reason.
   * @param string $message
   *   Message shown to the editor.
   * @param int $status
   *   HTTP status code.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The response.
   */
  protected function error(string $reason, string $message, int $status): JsonResponse {
    $response = new JsonResponse([
      'error' => $reason,
      'message' => $message,
    ], $status);

    $response->headers->set('Cache-Control', 'no-store, private');

    return $response;
  }

}
