<?php

declare(strict_types=1);

namespace Drupal\Tests\ifsc_autofill\Unit;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\ifsc_autofill\Exception\IfscLookupException;
use Drupal\ifsc_autofill\Service\IfscClient;
use GuzzleHttp\Client;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ConnectException;
use Psr\Log\NullLogger;

/**
 * @coversDefaultClass \Drupal\ifsc_autofill\Service\IfscClient
 *
 * @group ifsc_autofill
 */
class IfscClientTest extends UnitTestCase {

  /**
   * A realistic upstream payload.
   */
  protected const PAYLOAD = [
    'IFSC' => 'SBIN0030381',
    'BANK' => 'State Bank of India',
    'BRANCH' => 'INDORE',
    'ADDRESS' => 'MG ROAD, INDORE',
    'CITY' => 'INDORE',
    'DISTRICT' => 'INDORE',
    'STATE' => 'MADHYA PRADESH',
    'CENTRE' => 'INDORE',
    'CONTACT' => '+917312345678',
    'MICR' => '452002025',
    'BANKCODE' => 'SBIN',
    'SWIFT' => NULL,
    'UPI' => TRUE,
    'NEFT' => TRUE,
    'RTGS' => TRUE,
    'IMPS' => FALSE,
  ];

  /**
   * The cache backend double.
   *
   * @var \PHPUnit\Framework\MockObject\MockObject&\Drupal\Core\Cache\CacheBackendInterface
   */
  protected $cache;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->cache = $this->createMock(CacheBackendInterface::class);
    $this->cache->method('get')->willReturn(FALSE);
  }

  /**
   * @covers ::normalize
   */
  public function testNormalizeStripsSeparatorsAndCase(): void {
    $client = $this->buildClient([new Response(200, [], '{}')]);

    $this->assertSame('SBIN0030381', $client->normalize(' sbin-0030 381 '));
  }

  /**
   * @covers ::isValid
   */
  public function testIsValidRejectsMalformedCodes(): void {
    $client = $this->buildClient([new Response(200, [], '{}')]);

    $this->assertTrue($client->isValid('SBIN0030381'));
    $this->assertFalse($client->isValid('SBIN1030381'), 'The fifth character must be a zero.');
    $this->assertFalse($client->isValid('SBIN003038'), 'Ten characters is too short.');
    $this->assertFalse($client->isValid('SB1N0030381'), 'The bank code must be letters.');
  }

  /**
   * @covers ::lookup
   */
  public function testLookupRejectsMalformedCodeWithoutCallingTheService(): void {
    $client = $this->buildClient([]);

    $this->expectException(IfscLookupException::class);
    $client->lookup('NOPE');
  }

  /**
   * @covers ::lookup
   * @covers ::extract
   */
  public function testLookupReturnsNormalisedTokens(): void {
    $client = $this->buildClient([
      new Response(200, ['Content-Type' => 'application/json'], json_encode(self::PAYLOAD)),
    ]);

    $result = $client->lookup('sbin0030381');

    $this->assertIsArray($result);
    $this->assertSame('State Bank of India', $result['BANK']);
    $this->assertSame('INDORE', $result['BRANCH']);
    $this->assertSame('452002025', $result['MICR']);
    $this->assertSame('SBIN0030381', $result['IFSC']);
    $this->assertSame('Yes', $result['UPI'], 'Booleans become readable strings.');
    $this->assertSame('No', $result['IMPS']);
    $this->assertSame('', $result['SWIFT'], 'A null value becomes an empty string.');
  }

  /**
   * @covers ::lookup
   */
  public function testUnknownCodeReturnsNull(): void {
    $request = new Request('GET', 'https://example.com/SBIN0000001');
    $client = $this->buildClient([
      new ClientException('Not Found', $request, new Response(404)),
    ]);

    $this->assertNull($client->lookup('SBIN0000001'));
  }

  /**
   * @covers ::lookup
   */
  public function testEmptyPayloadReturnsNull(): void {
    $client = $this->buildClient([
      new Response(200, [], '{"IFSC":null}'),
    ]);

    $this->assertNull($client->lookup('SBIN0030381'));
  }

  /**
   * @covers ::lookup
   */
  public function testTransportFailureThrows(): void {
    $request = new Request('GET', 'https://example.com/SBIN0030381');
    $client = $this->buildClient([
      new ConnectException('Connection timed out', $request),
    ]);

    $this->expectException(IfscLookupException::class);
    $client->lookup('SBIN0030381');
  }

  /**
   * @covers ::lookup
   */
  public function testCachedResultSkipsTheRequest(): void {
    $cached = (object) ['data' => ['BANK' => 'Cached Bank', 'BRANCH' => 'INDORE']];

    $cache = $this->createMock(CacheBackendInterface::class);
    $cache->method('get')->willReturn($cached);
    $cache->expects($this->never())->method('set');

    // An empty queue means any HTTP call would fail the test.
    $client = $this->buildClient([], $cache);

    $this->assertSame('Cached Bank', $client->lookup('SBIN0030381')['BANK']);
  }

  /**
   * Builds a client backed by a queue of Guzzle responses.
   *
   * @param array $queue
   *   Responses or exceptions the mock handler should return in order.
   * @param \Drupal\Core\Cache\CacheBackendInterface|null $cache
   *   An alternative cache double.
   *
   * @return \Drupal\ifsc_autofill\Service\IfscClient
   *   The client under test.
   */
  protected function buildClient(array $queue, ?CacheBackendInterface $cache = NULL): IfscClient {
    $handler = HandlerStack::create(new MockHandler($queue));

    $time = $this->createMock(TimeInterface::class);
    $time->method('getRequestTime')->willReturn(1700000000);

    $client = new IfscClient(
      new Client(['handler' => $handler]),
      $cache ?? $this->cache,
      $this->getConfigFactoryStub([
        'ifsc_autofill.settings' => [
          'endpoint' => 'https://example.com',
          'timeout' => 5,
          'cache_max_age' => 604800,
          'negative_cache_max_age' => 3600,
        ],
      ]),
      new NullLogger(),
      $time,
    );
    $client->setStringTranslation($this->getStringTranslationStub());

    return $client;
  }

}
