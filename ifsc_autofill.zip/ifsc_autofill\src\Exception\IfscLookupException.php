<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Exception;

/**
 * Thrown when an IFSC lookup cannot be completed.
 *
 * The exception code carries the HTTP status the controller should return.
 */
class IfscLookupException extends \RuntimeException {

  /**
   * Machine readable reason, exposed to the client.
   *
   * @var string
   */
  protected string $reason;

  /**
   * Constructs the exception.
   *
   * @param string $message
   *   Human readable message, safe to show to an editor.
   * @param string $reason
   *   Machine readable reason such as "invalid" or "unavailable".
   * @param int $status
   *   HTTP status code to return.
   * @param \Throwable|null $previous
   *   The underlying exception, if any.
   */
  public function __construct(string $message, string $reason = 'unavailable', int $status = 502, ?\Throwable $previous = NULL) {
    parent::__construct($message, $status, $previous);
    $this->reason = $reason;
  }

  /**
   * Returns the machine readable reason.
   *
   * @return string
   *   The reason string.
   */
  public function getReason(): string {
    return $this->reason;
  }

  /**
   * Returns the HTTP status to send.
   *
   * @return int
   *   An HTTP status code.
   */
  public function getStatusCode(): int {
    $code = (int) $this->getCode();
    return $code >= 400 && $code <= 599 ? $code : 502;
  }

}
