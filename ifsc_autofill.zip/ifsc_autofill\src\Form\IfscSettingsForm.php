<?php

declare(strict_types=1);

namespace Drupal\ifsc_autofill\Form;

use Drupal\Core\Cache\CacheTagsInvalidatorInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\ifsc_autofill\Exception\IfscLookupException;
use Drupal\ifsc_autofill\IfscTokens;
use Drupal\ifsc_autofill\Service\IfscClientInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configures the lookup endpoint, caching and rate limits.
 */
class IfscSettingsForm extends ConfigFormBase {

  /**
   * Wrapper ID for the connection test result.
   */
  protected const TEST_WRAPPER = 'ifsc-autofill-test-result';

  /**
   * The IFSC client.
   */
  protected IfscClientInterface $client;

  /**
   * The cache tags invalidator.
   */
  protected CacheTagsInvalidatorInterface $cacheTagsInvalidator;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    $form = parent::create($container);
    $form->client = $container->get('ifsc_autofill.client');
    $form->cacheTagsInvalidator = $container->get('cache_tags.invalidator');

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'ifsc_autofill_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['ifsc_autofill.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('ifsc_autofill.settings');

    $form['intro'] = [
      '#type' => 'html_tag',
      '#tag' => 'p',
      '#value' => $this->t('These settings control how codes are resolved. Choose which forms are covered on the <a href=":url">Mappings</a> tab.', [
        ':url' => Url::fromRoute('entity.ifsc_mapping.collection')->toString(),
      ]),
    ];

    $form['endpoint'] = [
      '#type' => 'url',
      '#title' => $this->t('Lookup endpoint'),
      '#description' => $this->t('Base URL of a service that answers <code>GET {endpoint}/{IFSC}</code> with JSON. Defaults to the public Razorpay directory. Point this at an internal mirror if outbound requests are restricted.'),
      '#default_value' => $config->get('endpoint'),
      '#required' => TRUE,
    ];

    $form['timeout'] = [
      '#type' => 'number',
      '#title' => $this->t('Request timeout'),
      '#field_suffix' => $this->t('seconds'),
      '#default_value' => $config->get('timeout'),
      '#min' => 1,
      '#max' => 30,
      '#required' => TRUE,
    ];

    $form['caching'] = [
      '#type' => 'details',
      '#title' => $this->t('Caching'),
      '#open' => TRUE,
    ];

    $form['caching']['cache_max_age'] = [
      '#type' => 'number',
      '#title' => $this->t('Keep successful lookups for'),
      '#field_suffix' => $this->t('seconds'),
      '#description' => $this->t('Branch details change rarely. 604800 is one week. Use 0 to disable caching.'),
      '#default_value' => $config->get('cache_max_age'),
      '#min' => 0,
      '#required' => TRUE,
    ];

    $form['caching']['negative_cache_max_age'] = [
      '#type' => 'number',
      '#title' => $this->t('Keep "not found" answers for'),
      '#field_suffix' => $this->t('seconds'),
      '#description' => $this->t('Stops repeated typos from reaching the directory. Keep this short so newly opened branches are picked up.'),
      '#default_value' => $config->get('negative_cache_max_age'),
      '#min' => 0,
      '#required' => TRUE,
    ];

    $form['caching']['clear'] = [
      '#type' => 'submit',
      '#value' => $this->t('Clear cached lookups'),
      '#submit' => ['::clearCache'],
      '#limit_validation_errors' => [],
    ];

    $form['limits'] = [
      '#type' => 'details',
      '#title' => $this->t('Rate limiting'),
      '#open' => FALSE,
    ];

    $form['limits']['flood_limit'] = [
      '#type' => 'number',
      '#title' => $this->t('Maximum lookups per user'),
      '#description' => $this->t('Counted per window, per authenticated user or client IP. Use 0 to disable.'),
      '#default_value' => $config->get('flood_limit'),
      '#min' => 0,
      '#required' => TRUE,
    ];

    $form['limits']['flood_window'] = [
      '#type' => 'number',
      '#title' => $this->t('Window'),
      '#field_suffix' => $this->t('seconds'),
      '#default_value' => $config->get('flood_window'),
      '#min' => 1,
      '#required' => TRUE,
    ];

    $form['limits']['debounce'] = [
      '#type' => 'number',
      '#title' => $this->t('Typing debounce'),
      '#field_suffix' => $this->t('milliseconds'),
      '#description' => $this->t('How long the browser waits after the last keystroke before looking a code up.'),
      '#default_value' => $config->get('debounce'),
      '#min' => 0,
      '#max' => 5000,
      '#required' => TRUE,
    ];

    $form['test'] = [
      '#type' => 'details',
      '#title' => $this->t('Test the connection'),
      '#open' => FALSE,
    ];

    $form['test']['code'] = [
      '#type' => 'textfield',
      '#title' => $this->t('IFSC code'),
      '#placeholder' => 'SBIN0030381',
      '#maxlength' => IfscTokens::CODE_LENGTH,
      '#size' => 20,
    ];

    $form['test']['run'] = [
      '#type' => 'submit',
      '#value' => $this->t('Run lookup'),
      '#limit_validation_errors' => [['code']],
      '#submit' => ['::noop'],
      '#ajax' => [
        'callback' => '::testLookup',
        'wrapper' => self::TEST_WRAPPER,
        'progress' => ['type' => 'throbber', 'message' => $this->t('Looking up…')],
      ],
    ];

    $form['test']['result'] = [
      '#type' => 'container',
      '#attributes' => ['id' => self::TEST_WRAPPER],
      'placeholder' => [
        '#markup' => '<p>' . $this->t('The lookup runs against the endpoint saved above, using the same cache as the editor forms.') . '</p>',
      ],
    ];

    $form['#attached']['library'][] = 'ifsc_autofill/admin';

    return parent::buildForm($form, $form_state);
  }

  /**
   * Submit handler that only triggers a rebuild for the AJAX test.
   *
   * @param array $form
   *   The form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function noop(array &$form, FormStateInterface $form_state): void {
    $form_state->setRebuild();
  }

  /**
   * AJAX callback rendering the result of a test lookup.
   *
   * @param array $form
   *   The form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The replacement render array.
   */
  public function testLookup(array &$form, FormStateInterface $form_state): array {
    $code = (string) $form_state->getValue('code');
    $container = [
      '#type' => 'container',
      '#attributes' => ['id' => self::TEST_WRAPPER],
    ];

    if (trim($code) === '') {
      $container['message'] = [
        '#markup' => '<p>' . $this->t('Enter a code first.') . '</p>',
      ];

      return $container;
    }

    try {
      $data = $this->client->lookup($code);
    }
    catch (IfscLookupException $e) {
      $container['message'] = [
        '#theme' => 'status_messages',
        '#message_list' => ['error' => [$e->getMessage()]],
      ];

      return $container;
    }

    if ($data === NULL) {
      $container['message'] = [
        '#theme' => 'status_messages',
        '#message_list' => ['warning' => [$this->t('No bank found for that code.')]],
      ];

      return $container;
    }

    $rows = [];
    foreach (IfscTokens::definitions() as $token => $label) {
      if (($data[$token] ?? '') !== '') {
        $rows[] = [$label, $token, $data[$token]];
      }
    }

    $container['message'] = [
      '#theme' => 'status_messages',
      '#message_list' => ['status' => [$this->t('Lookup succeeded.')]],
    ];
    $container['table'] = [
      '#type' => 'table',
      '#header' => [$this->t('Value'), $this->t('Token'), $this->t('Result')],
      '#rows' => $rows,
    ];

    return $container;
  }

  /**
   * Submit handler for the cache clear button.
   *
   * @param array $form
   *   The form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function clearCache(array &$form, FormStateInterface $form_state): void {
    $this->cacheTagsInvalidator->invalidateTags([IfscClientInterface::CACHE_TAG]);
    $this->messenger()->addStatus($this->t('Cached IFSC lookups cleared.'));
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    parent::validateForm($form, $form_state);

    $endpoint = (string) $form_state->getValue('endpoint');
    if ($endpoint !== '' && !in_array(parse_url($endpoint, PHP_URL_SCHEME), ['http', 'https'], TRUE)) {
      $form_state->setErrorByName('endpoint', $this->t('The endpoint must be an http or https URL.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $this->config('ifsc_autofill.settings')
      ->set('endpoint', rtrim((string) $form_state->getValue('endpoint'), '/'))
      ->set('timeout', (int) $form_state->getValue('timeout'))
      ->set('cache_max_age', (int) $form_state->getValue('cache_max_age'))
      ->set('negative_cache_max_age', (int) $form_state->getValue('negative_cache_max_age'))
      ->set('flood_limit', (int) $form_state->getValue('flood_limit'))
      ->set('flood_window', (int) $form_state->getValue('flood_window'))
      ->set('debounce', (int) $form_state->getValue('debounce'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
