# IFSC Autofill

Type an Indian bank IFSC code on any entity form and the bank name, branch,
address, MICR code, city and state fill themselves in.

Nothing is hard coded. An administrator picks the entity type, the bundle, the
field that holds the code, and which field receives each value, so the same
module serves a node form, a user profile, a commerce store or a custom entity
without a line of extra code.

- Compatible with Drupal 10, 11 and 12.
- No payment gateway, no API key, no account.
- Works with the public Razorpay IFSC directory by default; can be pointed at
  any host that answers `GET {endpoint}/{IFSC}` with the same JSON.

## Requirements

Drupal core only. `field` is the single dependency and the HTTP client that
ships with core does the lookups.

## Installation

```bash
# unzip into modules/custom, then
drush en ifsc_autofill
drush cr
```

## Setup

### 1. Grant the permission

*People → Permissions*

| Permission | Give it to |
| --- | --- |
| Use IFSC Autofill | every role that fills in the form |
| Administer IFSC Autofill | site administrators only |

Without **Use IFSC Autofill** the JavaScript is not attached and the lookup
endpoint returns 403.

### 2. Check the endpoint

*Configuration → Web services → IFSC Autofill*

The default endpoint is `https://ifsc.razorpay.com`. Open **Test the
connection**, enter `SBIN0030381` and press **Run lookup** to confirm the site
can reach it. If outbound HTTP is blocked, point the endpoint at an internal
mirror instead.

Also on this screen: cache lifetimes, rate limiting and the typing debounce.

### 3. Prepare the fields

On the bundle you want to cover, add:

- one field for the code, for example `field_ifsc` (Text, plain — max length 11)
- one field per value you want filled, for example `field_bank_name`,
  `field_branch_name`, `field_branch_address`, `field_micr`, `field_city`,
  `field_state`

Supported field types: **Text (plain)**, **Text (plain, long)**,
**List (text)**, **Telephone** and **Email**. Formatted text is deliberately
excluded because a text format widget cannot be filled reliably.

### 4. Create the mapping

*Configuration → Web services → IFSC Autofill → Mappings → Add mapping*

| Setting | What it does |
| --- | --- |
| Entity type / Bundle | Which form the mapping applies to |
| IFSC code field | The field the editor types into |
| Fields to fill | One select per value; leave empty to skip |
| When a field already has a value | Keep what the editor typed, or replace it |
| Make the filled fields read only | Stops hand edits of the derived values |
| Enabled | Turn the mapping off without deleting it |

One mapping per entity type and bundle. Add as many mappings as you need.

## How an editor experiences it

1. They type `SBIN0030381` into the IFSC field.
2. Half a second after they stop typing — or on blur, or on Enter — the lookup
   runs.
3. A status line under the field shows `State Bank of India, Indore.` and the
   mapped fields are filled.
4. A wrong code shows `An IFSC code is 11 characters, for example SBIN0030381.`
   and nothing is touched.
5. Clearing the code clears the fields this module filled, and only those.

## Values available

| Token | Meaning |
| --- | --- |
| `BANK` | Bank name |
| `BRANCH` | Branch name |
| `ADDRESS` | Branch address |
| `CITY` | City |
| `DISTRICT` | District |
| `STATE` | State |
| `CENTRE` | Centre |
| `CONTACT` | Contact number |
| `MICR` | MICR code |
| `BANKCODE` | Bank code |
| `SWIFT` | SWIFT code |
| `IFSC` | The normalised code |
| `NEFT` / `RTGS` / `IMPS` / `UPI` | Yes or No |

## Behaviour worth knowing

**Caching.** A successful lookup is cached for a week in its own cache bin, a
"not found" answer for an hour. Both are configurable and can be flushed from
the settings form. The upstream service is contacted once per code per site,
not once per form load.

**Rate limiting.** Core flood control caps lookups at 60 per minute per
authenticated user or client IP. Set the limit to 0 to disable.

**Overwrite safety.** With the default *Keep what the editor typed*, a field is
only filled when it is empty or when this module filled it earlier. Correcting
a typo therefore updates the derived fields, while a manually entered branch
name survives.

**Server side validation.** The code format is checked in the browser and again
in the controller. Malformed codes never reach the upstream service.

**No client secrets.** The browser never talks to the directory directly; it
calls this site, which does the request. That keeps the endpoint swappable and
the traffic inside your own logging.

## Programmatic use

```php
/** @var \Drupal\ifsc_autofill\Service\IfscClientInterface $client */
$client = \Drupal::service('ifsc_autofill.client');

$details = $client->lookup('sbin0030381');
// NULL when the directory does not know the code.
// Throws IfscLookupException when the code is malformed or the service failed.

$details['BANK'];   // 'STATE BANK OF INDIA'
$details['BRANCH']; // 'INDORE'
```

Swap the implementation by overriding the `ifsc_autofill.client` service if you
hold the IFSC directory in your own database.

## Uninstall

```bash
drush pmu ifsc_autofill
```

Mappings and settings are removed with the module. Field values already saved on
entities are left alone.

## Data source

The default endpoint is the public IFSC directory published by Razorpay, built
from the Reserve Bank of India's branch list. It needs no key and no account.
This module is not affiliated with Razorpay.

## License

GPL-2.0-or-later.
